const { User, Caregiver } = require('../models');
const ErrorResponse = require('../utils/errorResponse');
const { Op } = require('sequelize');

// @desc    Get all caregivers
// @route   GET /api/caregivers
// @access  Private/Admin
exports.getCaregivers = async (req, res, next) => {
    try {
        const caregivers = await Caregiver.findAll({
            include: [{
                model: User,
                as: 'caregiverUser',
                attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'profileImage']
            }],
            order: [['createdAt', 'DESC']]
        });

        // Format the response to include user data
        const formattedCaregivers = caregivers.map(caregiver => ({
            id: caregiver.id,
            userId: caregiver.userId,
            name: `${caregiver.caregiverUser?.firstName || ''} ${caregiver.caregiverUser?.lastName || ''}`.trim(),
            email: caregiver.caregiverUser?.email,
            phone: caregiver.caregiverUser?.phone,
            profileImage: caregiver.caregiverUser?.profileImage,
            specialization: caregiver.specialization,
            experience: caregiver.experience,
            status: caregiver.status,
            availability: caregiver.availability,
            skills: caregiver.skills,
            dateOfBirth: caregiver.dateOfBirth,
            address: caregiver.address,
            city: caregiver.city,
            state: caregiver.state,
            zipCode: caregiver.zipCode,
            emergencyContact: caregiver.emergencyContact,
            emergencyPhone: caregiver.emergencyPhone,
            hourlyRate: caregiver.hourlyRate,
            languages: caregiver.languages,
            certifications: caregiver.certifications,
            createdAt: caregiver.createdAt,
            updatedAt: caregiver.updatedAt
        }));

        res.status(200).json({
            success: true,
            count: formattedCaregivers.length,
            data: formattedCaregivers
        });
    } catch (error) {
        console.error('Error fetching caregivers:', error);
        next(error);
    }
};
// @desc    Create a new caregiver
// @route   POST /api/caregivers
// @access  Private/Admin
exports.createCaregiver = async (req, res, next) => {
    try {
        const {
            userId,
            specialization,
            experience,
            bio,
            availability,
            status,
            skills,
            dateOfBirth,
            address,
            city,
            state,
            zipCode,
            emergencyContact,
            emergencyPhone,
            hourlyRate,
            languages,
            certifications
        } = req.body;
        // Check if user exists
        const user = await User.findByPk(userId);
        if (!user) {
            return next(new ErrorResponse('User not found', 404));
        }
        // Check if caregiver profile already exists for this user
        const existingCaregiver = await Caregiver.findOne({ where: { userId } });
        if (existingCaregiver) {
            return next(new ErrorResponse('Caregiver profile already exists for this user', 400));
        }
        // Create caregiver profile
        const caregiver = await Caregiver.create({
            userId,
            specialization,
            experience,
            bio,
            availability: availability || 'available', // Default to 'available' if not provided
            status: status || 'active', // Default to 'active' if not provided
            skills,
            dateOfBirth,
            address,
            city,
            state,
            zipCode,
            emergencyContact,
            emergencyPhone,
            hourlyRate,
            languages,
            certifications
        });
        res.status(201).json({
            success: true,
            data: caregiver
        });
    } catch (error) {
        console.error('Error in createCaregiver:', error);
        next(error);
    }
};
// @desc    Update caregiver
// @route   PUT /api/caregivers/:id
// @access  Private/Admin
exports.updateCaregiver = async (req, res, next) => {
    try {
        const { id } = req.params;
        const {
            name, email, phone,
            specialization, experience, bio,
            availability, status, skills,
            dateOfBirth, address, city,
            state, zipCode, emergencyContact,
            emergencyPhone, profileImage,
            hourlyRate, languages, certifications
        } = req.body;

        // Find the caregiver with associated user
        const caregiver = await Caregiver.findByPk(id, {
            include: [{
                model: User,
                as: 'caregiverUser',
                attributes: ['id', 'name', 'email', 'phone']
            }]
        });

        if (!caregiver) {
            return next(new ErrorResponse('Caregiver not found', 404));
        }

        // Start a transaction
        const transaction = await Caregiver.sequelize.transaction();

        try {
            // Update user details
            if (caregiver.caregiverUser) {
                await caregiver.caregiverUser.update({
                    name: name || caregiver.caregiverUser.name,
                    email: email || caregiver.caregiverUser.email,
                    phone: phone || caregiver.caregiverUser.phone
                }, { transaction });
            }

            // Update caregiver details
            const caregiverData = {
                specialization: specialization || caregiver.specialization,
                experience: experience || caregiver.experience,
                bio: bio || caregiver.bio,
                availability: availability || caregiver.availability,
                status: status || caregiver.status,
                skills: skills || caregiver.skills,
                dateOfBirth: dateOfBirth || caregiver.dateOfBirth,
                address: address || caregiver.address,
                city: city || caregiver.city,
                state: state || caregiver.state,
                zipCode: zipCode || caregiver.zipCode,
                emergencyContact: emergencyContact || caregiver.emergencyContact,
                emergencyPhone: emergencyPhone || caregiver.emergencyPhone,
                profileImage: profileImage || caregiver.profileImage,
                hourlyRate: hourlyRate || caregiver.hourlyRate,
                languages: languages || caregiver.languages,
                certifications: certifications || caregiver.certifications
            };

            await caregiver.update(caregiverData, { transaction });

            // Commit the transaction
            await transaction.commit();

            // Fetch the updated caregiver with user details
            const updatedCaregiver = await Caregiver.findByPk(id, {
                include: [{
                    model: User,
                    as: 'caregiverUser',
                    attributes: ['name', 'email', 'phone']
                }]
            });

            res.status(200).json({
                success: true,
                data: updatedCaregiver
            });

        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            throw error;
        }

    } catch (error) {
        next(error);
    }
};

// @desc    Delete caregiver
// @route   DELETE /api/caregivers/:id
// @access  Private/Admin
exports.deleteCaregiver = async (req, res, next) => {
    try {
        const { id } = req.params;

        // Find the caregiver with associated user
        const caregiver = await Caregiver.findByPk(id, {
            include: [{
                model: User,
                as: 'caregiverUser'
            }]
        });

        if (!caregiver) {
            return next(new ErrorResponse('Caregiver not found', 404));
        }

        // Start a transaction
        const transaction = await Caregiver.sequelize.transaction();

        try {
            // Delete the caregiver record
            await caregiver.destroy({ transaction });

            // Also delete the associated user
            if (caregiver.caregiverUser) {
                await caregiver.caregiverUser.destroy({ transaction });
            }

            // Commit the transaction
            await transaction.commit();

            res.status(200).json({
                success: true,
                data: {}
            });

        } catch (error) {
            // Rollback the transaction in case of error
            await transaction.rollback();
            throw error;
        }

    } catch (error) {
        next(error);
    }
};
