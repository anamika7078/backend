const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                notEmpty: true,
                len: [2, 100]
            }
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: {
                msg: 'Email already exists'
            },
            validate: {
                isEmail: {
                    msg: 'Please provide a valid email'
                },
                notEmpty: {
                    msg: 'Email is required'
                }
            }
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                notEmpty: {
                    msg: 'Password is required'
                },
                len: {
                    args: [6],
                    msg: 'Password must be at least 6 characters long'
                }
            }
        },
        phone: {
            type: DataTypes.STRING,
            validate: {
                isNumeric: {
                    msg: 'Phone number should contain only numbers'
                },
                len: {
                    args: [10, 15],
                    msg: 'Phone number should be between 10 and 15 digits'
                }
            }
        },
        role: {
            type: DataTypes.ENUM('User', 'Caregiver', 'Admin'),
            allowNull: false,
            defaultValue: 'User'
        },
        isActive: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        lastLogin: {
            type: DataTypes.DATE
        },
        resetPasswordToken: {
            type: DataTypes.STRING
        },
        resetPasswordExpire: {
            type: DataTypes.DATE
        }
    }, {
        tableName: 'users',
        timestamps: true, // This will automatically add createdAt and updatedAt
        paranoid: true, // Enable soft deletes
        createdAt: 'created_at',
        updatedAt: 'updated_at',
        deletedAt: 'deleted_at',
        defaultScope: {
            attributes: { exclude: ['password'] } // Don't return password by default
        },
        scopes: {
            withPassword: {
                attributes: { include: ['password'] } // Only include password when explicitly requested
            }
        },
        define: {
            timestamps: true,
            freezeTableName: true,
            underscored: true,
            paranoid: true
        }
    });

    // Instance Methods
    User.prototype.matchPassword = async function (enteredPassword) {
        return await bcrypt.compare(enteredPassword, this.password);
    };

    User.prototype.getSignedJwtToken = function () {
        return jwt.sign(
            { id: this.id, role: this.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRE || '7d' }
        );
    };

    // Generate and hash password reset token
    User.prototype.getResetPasswordToken = function () {
        // Generate token
        const crypto = require('crypto');
        const resetToken = crypto.randomBytes(20).toString('hex');

        // Hash token and set to resetPasswordToken field
        this.resetPasswordToken = crypto
            .createHash('sha256')
            .update(resetToken)
            .digest('hex');

        // Set expire (10 minutes)
        this.resetPasswordExpire = Date.now() + 10 * 60 * 1000;

        return resetToken;
    };

    // Hooks
    User.beforeSave(async (user) => {
        if (user.password) {
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(user.password, salt);
        }
    });

    // Class Methods
    User.associate = function (models) {
        // Define associations here
        // Example: User.hasMany(models.Booking);
    };

    return User;
};